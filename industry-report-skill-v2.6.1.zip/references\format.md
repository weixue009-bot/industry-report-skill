# 分析字段写作规范

## 核心环节命名规则（重要）

`supply_chain.core_segments[]` 的每一项必须满足以下规则：

1. **第一部分（不含括号）必须与 `segments[].name` 完全一致**——模板 `renderSupplyChain()` 按 core_segments 名称模糊匹配 segment.name，再从 segments 数组取 value_ratio 挂到 box 上显示；若名称不匹配，该环节的价值量占比不会显示。
2. **可选加括号说明**：若需要补充说明，格式为 `"环节名（说明文字）"`，模板 `formatItem()` 会自动拆分：括号外为标题，括号内为描述，标题部分必须与 segment.name 完全一致。

**示例**（segments.name = "CXO产业链"）：
```json
"core_segments": [
  "CXO产业链（研发生产外包）",     // ✅ 标题"CXO产业链"精确匹配 segment.name
  "ADC/双抗前沿技术",               // ✅ 无需括号时直接与 segment.name 完全一致
  "创新中药"                        // ✅
]
```

**反例**：
```json
"core_segments": [
  "CXO/CRO/CDMO（研发生产外包）",  // ❌ 标题"CXO/CRO/CDMO"≠ segment.name"CXO产业链"
  "ADC/双抗等前沿技术平台"          // ❌ 标题"ADC/双抗等前沿技术平台"≠ segment.name"ADC/双抗前沿技术"
]
```

## 环节定位 (positioning)

- 说明该环节在产业链中的位置和作用
- 核心功能和不可替代性
- 典型产品的关键性能指标
- 控制在 80-150 字，一段话

写法参照：产业级说法，客观描述，不夸大

## 价值量占比 (value_ratio)

- 单位：百分比数字，不要带 `%` 符号
- 例如：19、13、16
- 该数值会渲染为环节子页右上角的大数字卡片
- 必须与 `overview.cost_breakdown` 中对应环节的 `ratio` 一致
- 模板自动按 `DATA.industry` 匹配 metric-desc 文本：人形机器人/工业机器人/机器人 → "占机器人BOM成本"；创新药 → "占创新药管线总价值"；CXO → "占CXO/CDMO总价值"；半导体/新能源/光伏/锂电池 → 对应表述；未匹配 → `占{行业名}产业总价值` 中性占位

## 国产化进展 (localization_progress)

- 说明该环节的国产化率现状
- 国内主要玩家及进展
- 与海外的差距和瓶颈
- 控制在 80-150 字

## 证据来源 (evidence_sources)

- 数组，每个元素包含：
  - `source`：研报标题（必填）
  - `institution`：券商/机构名（必填）
  - `date`：发布日期（可选，格式 YYYY-MM-DD）
- 只列真正支撑该环节结论的研报，不要堆砌

## 壁垒类型 (barrier_type)

三选一：
- `科技壁垒`：核心竞争要素是技术研发、专利、know-how
- `产能壁垒`：核心竞争要素是产能规模、成本控制、良率
- `科技+产能双壁垒`：两者兼备

## 国际竞争格局 (international_landscape)

推荐写成结构化对象：

```json
{
  "主导厂商": "海外龙头企业及特点",
  "份额结构": "海外市占率分布",
  "技术/工艺代差": "海外与国内的技术/工艺差距",
  "进入壁垒": "进入该市场的核心障碍"
}
```

## 国内竞争格局 (domestic_landscape)

推荐写成结构化对象：

```json
{
  "主导厂商": "国内主要参与者",
  "份额结构": "国内市占率分布",
  "技术/工艺代差": "国内追赶进展",
  "进入壁垒": "国内企业面临的壁垒"
}
```

> 旧版字符串仍兼容，但新报告建议统一用结构化对象，便于卡片分条展示。

> ⚠️ 4 个字段都必须填写真实内容，不要留"待补充"——这会暴露模板空缺。AI 应基于研报内容为每个字段填一段话（30-100字），无明确数据的环节可写"暂无公开市占率数据，主要由X、Y、Z 主导"。

## 核心环节价值量占比（supply_chain.core_segments）

格式：`["环节A（占比%）", "环节B（占比%）", ...]`

- 括号使用中文全角 `（X%）`
- 该字符串模板会自动拆分为加粗标题 + 灰色占比描述
- 必须与 `cost_breakdown` 中对应环节一致

## segment 全字段清单

每个 segment（环节）必须填写以下 **14 个字段**，模板 `renderSegment()` 对应渲染 **9 张卡片**。缺任意一个字段都会导致子环节页不完整。

> ⚠️ 标记"必填"的字段缺一不可；标记"可选"的字段有数据时应填。

| 序号 | 字段 | 模板渲染 | 必填 | 说明 |
|:--:|------|----------|:--:|------|
| 1 | `positioning` | 首屏三卡片·左 | ✅ | 环节定位 |
| 2 | `value_ratio` | 首屏三卡片·右上 | ✅ | 价值量占比数字 |
| 3 | `localization_progress` | 首屏三卡片·右下 | ✅ | 国产化进展 |
| 4 | `international_landscape` | 国际竞争格局 | ✅ | 结构化 4 字段 |
| 5 | `domestic_landscape` | 国内竞争格局 | ✅ | 结构化 4 字段 |
| 6 | `product_tiers` | **产品分层表格** | ✅ | 2-3 层级 |
| 7 | `barrier_type` + `barrier_detail` | 壁垒类型卡片 | ✅ | 三选一 |
| 8 | `failure_conditions` | 失败条件卡片 | ✅ | 2-4 条 |
| 9 | `profit_drivers` | **利润驱动表格** | ✅ | 2-4 项 |
| 10 | `tech_roadmap` | **技术路线图卡片** | ✅ | 2-3 条 |
| 11 | `scoring_dimensions` | **评分维度权重卡片** | ✅ | 5 维 |
| 12 | `stocks` | 核心标的表格 | ✅ | 2-4 支 |
| 13 | `evidence_sources` | **证据来源卡片** | ✅ | 3-5 条 |
| 14 | `eps_forecast`（stocks 子字段） | 盈利预测列 | 可选 | 有数据时填 |

### 模板渲染顺序

```
首屏三卡片 → 竞争格局(两栏) → 产品分层(表格) → 壁垒 → 失败条件
→ 利润驱动(表格) → 技术路线图 → 评分维度+标的(表格) → 证据来源
```

---

## 个股评分维度 (scoring_dimensions)

每个 segment 必须填写 5 维评分权重，用于渲染子环节页的"评分维度权重"卡片：

```json
"scoring_dimensions": [
  {"name": "不可替代性", "weight": "高"},
  {"name": "估值", "weight": "中"},
  {"name": "业绩", "weight": "中"},
  {"name": "客户", "weight": "高"},
  {"name": "管理层", "weight": "中低"}
]
```

- `name`：维度名称（与 `stocks[].score_detail` 的 key 一一对应）
- `weight`：该维度的权重（高/中/中低/低）
- 权重不设默认值——每个行业各维度的相对重要程度不同，AI 应基于研报中对该环节的核心竞争要素判断来设定
- `stocks[].score_detail` 中的 key 必须与 `scoring_dimensions[].name` 完全一致

五维度评分，每维度 0-100：
- **不可替代性**：产品技术壁垒、客户黏性、切换成本
- **估值**：PE/PB 分位数、与行业平均对比、与自身历史对比
- **业绩**：收入利润增速、毛利率趋势、订单可见度
- **客户**：客户质量（是否行业龙头）、客户集中度、新客户拓展进展
- **管理层**：团队背景、战略执行力、研发投入比例

评分依据必须来自研报原文，不可主观臆断。如研报未覆盖某维度，评分填 0 并在 note 中注明"研报未覆盖"。

---

## 产品分层 (product_tiers)

按产品等级、性能层级划分市场，模板渲染为带 5 列表格（层级 | 价格区间 | 典型玩家 | 毛利率 | 市占率）。

```json
"product_tiers": [
  {"tier": "高端", "asp": "价格区间", "key_players": "主要玩家", "margin": "毛利率", "market_share": "市占率"},
  {"tier": "中端", "asp": "价格区间", "key_players": "主要玩家", "margin": "毛利率", "market_share": "市占率"},
  {"tier": "低端", "asp": "价格区间", "key_players": "主要玩家", "margin": "毛利率", "market_share": "市占率"}
]
```

- `tier`：层级名称（如高端/中端/低端，或 FIC/BIC/Me-too，或 CDMO/CRO/CMO）
- `asp`：该层级的典型价格区间
- `key_players`：该层级的主要参与者
- `margin`：该层级的典型毛利率范围
- `market_share`：该层级在整体市场中的占比

要求：
- 至少分 2-3 个层级，跨度要覆盖主要市场结构
- 数据来源优先研报原文，无法获取时标注"估算"
- 不同层级的经济模型差异是核心洞察

---

## 利润驱动 (profit_drivers)

模板渲染为带 3 列表格（驱动因素 | 影响权重 | 说明），其中"影响权重"列用红/黄/灰标签表示高/中/低。

```json
"profit_drivers": [
  {"driver": "利润驱动项", "weight": "高", "note": "为什么是关键驱动"},
  {"driver": "利润驱动项", "weight": "中", "note": "说明"},
  {"driver": "利润驱动项", "weight": "中", "note": "说明"},
  {"driver": "利润驱动项", "weight": "中", "note": "说明"}
]
```

- `driver`：驱动因素名称（简短，5-10字）
- `weight`：影响权重（高/中/低），模板自动映射标签颜色
- `note`：一句话说明为什么该因素是利润驱动的核心（20-50字）

要求：
- 至少 2 项，建议 3-4 项覆盖主要利润弹性来源
- 每个行业的利润结构不同：CDMO 看产能利用率，创新药看出海定价，零部件看良率——应根据研报内容为每个环节定制
- 权重"高"的项应是研报中多次强调的利润弹性所在

---

## 技术路线图 (tech_roadmap)

模板渲染为卡片内的列表项，每项包含方向名称、时间线和影响说明。

```json
"tech_roadmap": [
  {"direction": "下一代技术方向", "timeline": "预计量产时间", "impact": "对竞争格局的影响"},
  {"direction": "替代技术风险", "timeline": "时间线", "impact": "如果发生会怎样"}
]
```

- `direction`：技术方向名称（简短，5-15字）
- `timeline`：预计时间线（如2027-2029年，或"3-5年内"）
- `impact`：对行业竞争格局或公司价值的影响描述（30-80字）

要求：
- 至少 2 条，建议 3 条（一项下一代技术、一项替代风险、一项工艺突破）
- 必须是该环节独有且真实存在的技术演进方向，不写泛化内容
- 数据来源优先研报中对技术路线的讨论

---

## 失败条件 (failure_conditions)

每个环节必须列出 2-4 条具体、可验证的反证条件。写出什么事实出现会推翻该环节的看好逻辑。

要求：
- 每条条件必须具体，不能写"行业风险""政策风险"等泛泛表述
- 优先写可观测的指标变化（如"市占率跌破X%"、"关键客户流失"、"毛利率下滑至Y%"）
- 区分"会削弱判断"和"直接推翻判断"的条件

---

## 来源分级 (source_grading)

对关键结论标注证据强度，帮助读者判断判断可信度。

三个等级：
- **强**：基于年报/公告/官方统计/交易所披露/业绩会纪要/项目备案等一手来源
- **中**：基于券商研报/行业期刊/可靠媒体/交叉验证的渠道调研
- **弱**：基于社交媒体/KOL观点/未验证传闻（仅作线索，不可独立作为结论依据）

要求：
- 在 `overview.conclusion` 末尾写一行：`来源等级：强(N条) | 中(N条) | 弱(N条)`
- 对基于弱来源的结论，必须在对应 `note` 中注明"需进一步验证"
- 优先使用强来源构建核心判断

---

## EPS 预测 (eps_forecast)

**可选字段**，仅当数据可用时填写（数据来源：东方财富 reportapi）。

```json
{
  "this_year": 1.23,
  "next_year": 1.56,
  "next_two_year": 1.89,
  "growth_rate": 26.8
}
```

- `this_year` / `next_year` / `next_two_year`：当年/明年/后年 EPS 预测（元）
- `growth_rate`：由 Agent 计算 `(next_year - this_year) / this_year * 100`，百分比
- 如只有部分年份数据，可只填已有字段
- 模板仅在环节中有任一股票含 eps_forecast 数据时才显示"盈利预测"列
- 表格显示格式：`1.23→1.56`（第一行） + `+26.8%`（第二行，红涨绿跌）
- 该数据仅反映券商预测，不构成投资建议，应在备注中注明"预测数据仅供参考"

---

## 大文件写入规范

**问题**：`Write` 工具有文件大小限制（约 30-40KB），直接写入大 JSON 会被静默截断，导致 `analysis.json` 后半部分（通常是最后 segment 的 stocks + evidence_sources + overview 的 core_stock_pool 等）丢失。

**规则**：
1. **分步编码**：不要一次性将完整 `analysis.json` 用 `Write` 或 `json.dumps()` 写入。应通过 Python 脚本分段构造 → `json.dump()` 输出
2. **逐 segment 写**：如果行业有 4+ 个完整 segment（每段 18 个字段），先将 overview 写为临时文件，再用 Python 脚本追加 segments
3. **写入后校验**：每次写入后执行 `json.load()` 验证完整性，确认 `segments` 数量 + 每个 segment 的 `stocks`、`product_tiers`、`profit_drivers` 等数组字段长度正确
4. **尾部字段**：`core_stock_pool`、`watch_metrics`、`segment_priority`、`production_timeline` 等 overview 尾部字段最易丢失，写入后优先检查

**示例校验命令**
```python
import json
d = json.load(open("analysis/industry/XX/analysis.json", "r", encoding="utf-8"))
assert len(d["segments"]) == N, f"segments 数量应为{N}"
for s in d["segments"]:
    assert len(s.get("stocks", [])) > 0, f"{s['name']} stocks 被截断"
    assert len(s.get("product_tiers", [])) >= 2, f"{s['name']} product_tiers 被截断"
print("校验通过")
```
